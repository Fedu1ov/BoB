class Resultset
  VERSION = 2
end
