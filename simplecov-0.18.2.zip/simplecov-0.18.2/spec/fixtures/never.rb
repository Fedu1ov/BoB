# This class is purely some
# comments
