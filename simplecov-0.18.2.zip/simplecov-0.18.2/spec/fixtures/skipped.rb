# Not relevant
# :nocov:
# Hash.new
# :nocov:
