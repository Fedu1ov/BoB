# frozen_string_literal: true

module SimpleCov
  VERSION = "0.18.2"
end
