# frozen_string_literal: true

class B
  def foo
    :foo
  end

  def bar
    :bar
  end
end
