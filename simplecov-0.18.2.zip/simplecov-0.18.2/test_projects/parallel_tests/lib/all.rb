# frozen_string_literal: true

require_relative "a"
require_relative "b"
require_relative "c"
require_relative "d"
